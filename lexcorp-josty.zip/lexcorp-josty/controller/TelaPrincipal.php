<?php

require("../model/ConnectionUtil.php");

$func = $_POST['func'];

switch($func){

	case 'andamento' : 
		
		$andamento = ;

	break;

	case 'fracassada' :

		$fracassada = ;

	break;

	case 'concluida' :

		$concluida = ;

	break;
}

?>
