<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title id="titulo">LEXCORP</title>

	<!-- Melhor compatibilidade para smartphones -->
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<!-- Nossos CSS -->
	<link rel="stylesheet" type="text/css" href="view/content/css/menu.css">
	<link rel="stylesheet" type="text/css" href="view/content/css/tabelas.css">
	<link rel="stylesheet" type="text/css" href="view/content/css/lex-corp.css">

	<!-- Nossos JS -->
	<script src="controller/js/login.js"></script>

	<!-- BOOTSTRAP -->
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
  	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

</head>
<body>

	<div id="spa-content"></div>

</body>
</html>